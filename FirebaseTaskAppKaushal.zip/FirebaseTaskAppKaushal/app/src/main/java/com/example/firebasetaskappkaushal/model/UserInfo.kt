package com.example.firebasetaskappkaushal.model

import android.os.Parcelable
import kotlinx.parcelize.IgnoredOnParcel
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

//@Serializable
//class UserInfo {
//    var id: String? = null
//    var firstName: String = ""
//    var lastName: String = ""
//    var gender: String = ""
//    var age: Int = 0
//    var classRoom: String = ""
//    var image: String? = null
//
//    constructor()
//    constructor(
//        id: String?,
//        firstName: String,
//        lastName: String,
//        gender: String,
//        age: Int,
//        classRoom: String,
//        image: String?
//    ) : this() {
//        this.id = id
//        this.firstName = firstName
//        this.lastName = lastName
//        this.gender = gender
//        this.age = age
//        this.classRoom = classRoom
//        this.image = image
//    }
//}

@Parcelize
data class UserInfo(
    val id: String,
    val firstName: String,
    val lastName: String,
    val gender: String,
    val age: Int,
    val classRoom: String,
    val image: String?
): Parcelable {
    constructor():this("","","","",0,"", null)
}